package main;

import java.util.Scanner;

import main.aquecimento.Desafio;

public class Main {

	public static void main(String[] args) {
		int escolhaMenu = 0;
		Scanner scanner = new Scanner(System.in);
		do {
			
			System.out.println("Informe a opção desejada:");
			System.out.println("1 - Imprimir triângulo");
			System.out.println("2 - Imprimir retângulo");
			System.out.println("0 - Sair");
			escolhaMenu = scanner.nextInt();
			
			
			switch (escolhaMenu) {
				case 1: {
					imprimeTriangulo(scanner);
					break;
				}
				case 2: {
					imprimeRetangulo(scanner);
					break;
				}
				case 3: {
					
					break;
				}
				default:
					
			}
		}while(escolhaMenu != 0);
		scanner.close();
		
		System.out.println("Execução finalizada.");
	}
	
	private static void imprimeTriangulo(Scanner scanner) {
		System.out.println("Informe a altura do triângulo:");
		int alturaTriangulo = scanner.nextInt();
		new Desafio().imprimeTrianguloRetangulo(alturaTriangulo);
	}
	
	private static void imprimeRetangulo(Scanner scanner) {
		System.out.println("Informe a altura do retângulo:");
		int alturaRetangulo = scanner.nextInt();
		System.out.println("Informe a largura do retângulo:");
		int larguraRetangulo = scanner.nextInt();
		new Desafio().imprimeRetanguloEDiagonalSuperiorDireita(alturaRetangulo, larguraRetangulo);
	}
}
