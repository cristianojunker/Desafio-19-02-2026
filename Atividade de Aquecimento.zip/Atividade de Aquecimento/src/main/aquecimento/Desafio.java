package main.aquecimento;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Stack;

public class Desafio {
	public void imprimeTrianguloRetangulo(int altura) {
		System.out.println("");
		System.out.println("========== TRIÂNGULO ==========");
		System.out.println("");
		for(int i=0; i<altura; i++) {
			for(int j=0; j<=i; j++) {
				System.out.print("*");
				if(j!=i) {
					System.out.print(" ");
				}
			}
			System.out.print("\n");
		}
	}
	
	public void imprimeRetanguloEDiagonalSuperiorDireita(int altura, int largura) {
		System.out.println("");
		System.out.println("========== RETÂNGULO ==========");
		System.out.println("");
		for(int i=0; i<altura; i++) {
			for(int j=0; j<largura; j++) {
				if(j!=largura-1) {
					System.out.print("* ");
				}else {
					System.out.println("*");
				}
			}
		}
		System.out.println("");
		System.out.println("");
		for(int i=0; i<altura; i++) {
			for(int j=0; j<largura; j++) {
				if(i>j) {
					System.out.print("  ");
				}else if(j!=largura-1) {
					System.out.print("* ");
				}else {
					System.out.println("*");
				}
			}
		}
	}
	
	public void verificaEquilibioEquacao(String expressaoMatematica) {
		String[] arrayTokens = expressaoMatematica.split(" ");
		for(int i=0; i<arrayTokens.length; i++) {
			arrayTokens[i] = arrayTokens[i].trim();
		}
		
//		Stack<String> pilhaTokens = new Stack<>();
//		Collections.addAll(pilhaTokens, arrayTokens);
		
		ArrayList<Character> operadores = this.getOperadores();
		HashMap<Character,Character> delimitadores = this.getDelimitadores();
		
		char tokenAtual;
		char tokenAnterior;
		char tokenFechamentoEsperado;
		
		for(int i=0; i<arrayTokens.length; i++) {
			tokenAtual = arrayTokens[i].charAt(0);
			
			if(i==0 && operadores.contains(tokenAtual) && tokenAtual != '-') {
				System.out.println("Expressão inválida.");
				return;
			}else if(tokenAtual == '(') {
				tokenFechamentoEsperado = ')';
			}else if(tokenAtual == '[') {
				tokenFechamentoEsperado = ']';
			}else if(tokenAtual == '{') {
				tokenFechamentoEsperado = '}';
			}
			
			
			tokenAnterior = tokenAtual;
		}
	}
	
	private HashMap<Character,Character> getDelimitadores(){
		HashMap<Character,Character> hashMap = new HashMap<>();
		
		hashMap.put('(', ')');
		hashMap.put('[', ']');
		hashMap.put('{', '}');
		
		return hashMap;
	}
	
	private ArrayList<Character> getOperadores(){
		ArrayList<Character> arrayList = new ArrayList<>();
		
		arrayList.add('+');
		arrayList.add('-');
		arrayList.add('*');
		arrayList.add('-');
		
		return arrayList;
	}
}
